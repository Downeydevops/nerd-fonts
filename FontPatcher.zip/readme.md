
# Nerd Fonts

This is the font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Licensing

This script has an MIT license.

The added icons' authors and licenses can be found in the `src/` subdirectory.

## Version
This archive is created from

        commit 7352c79ca82e3f4335cd1c5e95eb7d1272821139
        Author: Fini <ulf.fini.jastrow@desy.de>
        Date:   Mon Jul 20 18:46:23 2026 +0200
        
            Merge pull request #2029 from ryanoasis/feature/fontlogos14
            
            Update Font Logos to 1.4.0
